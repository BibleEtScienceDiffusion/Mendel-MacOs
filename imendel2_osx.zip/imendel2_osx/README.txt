
NOTE: This version will only work on Mac OS X systems.
If you have a Windows or Linux machines, please select
the specific download for your platform.

INSTALLATION:

Easy method to install Mendel's Accountant:

1. Double click "install"

2. After install, point your web browser to:
 
	http://localhost/mendel/v2.0.2/index.html

3. To uninstall, double click "uninstall"

ADDITIONAL NOTES: 

1. During installation, this version will ask you how much memory
you want to allow MENDEL to use. If you need to change the amount 
of memory which Mendel uses, edit the file:
/Library/WebServer/CGI-Executables/v2.0/config.inc
and the value of the variable $ram_per_job to the amount of RAM you 
have available.  More RAM means larger population sizes, more linkage 
blocks, etc.

2. If you already have Mendel installed, you may want to uninstall
before installing a new version.  If you uninstall Mendel, your 
data will still remain on your system and you will have access
with the newer version.

