<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML//EN">
<?
include "login/chklogin.php";
?>
<html>
<head>
<title></title>
<meta http-equiv="refresh" content="0; URL=/mendel/v2.0.0/index.php">
</head>

</html>
